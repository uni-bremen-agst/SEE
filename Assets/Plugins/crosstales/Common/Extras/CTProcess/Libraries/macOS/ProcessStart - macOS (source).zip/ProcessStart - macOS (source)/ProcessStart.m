//
//  ProcessStart.m
//  Version 2021.3.0
//
//  © 2020-2021 crosstales LLC (https://www.crosstales.com)
//
//source: https://stackoverflow.com/questions/412562/execute-a-terminal-command-from-a-cocoa-app

#import "ProcessStart.h"

const char* RunCommand(char* command) {

    ProcessStart* process = [[ProcessStart alloc] init];
    NSString* result = [process runCommand:[NSString stringWithUTF8String:command ?: ""]];
    
    return [result UTF8String];
}

@implementation ProcessStart

- (NSString *)runCommand:(NSString *)commandToRun
{
    NSTask *task = [[NSTask alloc] init];
    [task setLaunchPath:@"/bin/sh"];

    NSArray *arguments = [NSArray arrayWithObjects:
                          @"-c" ,
                          [NSString stringWithFormat:@"%@", commandToRun],
                          nil];
    NSLog(@"run command:%@", commandToRun);
    [task setArguments:arguments];

    NSPipe *pipe = [NSPipe pipe];
    [task setStandardOutput:pipe];

    NSFileHandle *file = [pipe fileHandleForReading];

    [task launch];

    NSData *data = [file readDataToEndOfFile];

    NSString *output = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    return output;
}

@end
