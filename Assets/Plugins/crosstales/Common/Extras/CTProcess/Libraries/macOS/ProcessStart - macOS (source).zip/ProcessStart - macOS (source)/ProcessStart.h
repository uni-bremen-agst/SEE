//
//  ProcessStart.h
//  Version 2021.3.0
//
//  © 2020-2021 crosstales LLC (https://www.crosstales.com)
//
#import <Foundation/Foundation.h>

@interface ProcessStart : NSObject

- (NSString *)runCommand:(NSString *)commandToRun;

@end
