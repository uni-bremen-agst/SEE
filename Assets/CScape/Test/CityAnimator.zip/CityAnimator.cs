﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using CScape;
using System.Linq;

public class CityAnimator : MonoBehaviour
{
    public GameObject streetDetails;
    BuildingModifier[] smArray;
    int[] floorNumbers;
    int[] targetFloorNumbers;
    int[] currentFloorNumbers;
    bool startLoop = false;
    int i = 0;
    public int stepsPerFrame = 1;
    int currentStep = 0;

    // Use this for initialization
    public void Start()
    {
        System.Array.Resize(ref floorNumbers, 0);
        System.Array.Resize(ref targetFloorNumbers, 0);
        System.Array.Resize(ref currentFloorNumbers, 0);
        System.Array.Resize(ref smArray, 0);

        foreach (Transform go in streetDetails.transform.Cast<Transform>().Reverse())
        {
            BuildingModifier bm = go.GetComponent(typeof(BuildingModifier)) as BuildingModifier;
            if (bm != null)
            {
                System.Array.Resize(ref floorNumbers, floorNumbers.Length + 1);
                System.Array.Resize(ref targetFloorNumbers, floorNumbers.Length);
                System.Array.Resize(ref currentFloorNumbers, floorNumbers.Length);
                System.Array.Resize(ref smArray, floorNumbers.Length);
                floorNumbers[floorNumbers.Length - 1] = bm.floorNumber;
                targetFloorNumbers[floorNumbers.Length - 1] = 1;
                smArray[floorNumbers.Length - 1] = bm;

            }
        }

        foreach (Transform go in streetDetails.transform.Cast<Transform>().Reverse())
        {
            BuildingModifier bm = go.GetComponent(typeof(BuildingModifier)) as BuildingModifier;
            bm.floorNumber = 1;
            bm.AwakeCity();
            bm.UpdateCity();
        }
        stepsPerFrame = floorNumbers.Length - 1;
        startLoop = true;
        
    }

    // Update is called once per frame
    void Update()
    {
        startLoop = true;
        currentStep = 0;
        while (startLoop) { 
            if (i < smArray.Length)
            {
                if (smArray[i].floorNumber < floorNumbers[i])
                    smArray[i].floorNumber = smArray[i].floorNumber + 1;
                currentFloorNumbers[i] = smArray[i].floorNumber;
                smArray[i].AwakeCity();
                smArray[i].UpdateCity();
                i++;
                if (i == smArray.Length) i = 0;
                if (currentStep < stepsPerFrame) currentStep = currentStep + 1;
                else startLoop = false;
            }
        }

    }
}
